package com.example.demo.user;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootUserStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
